package com.example.oluwatobiloba.mobilerecharge.utils;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AlertDialog;

public class Permission {

    public static final int MY_PERMISSIONS_REQUEST_CAMERA = 1001;
    Context context;
    int checkPermission;
    String permission;

    public Permission(Context context, String permission) {
        this.context = context;
        this.permission = permission;
    }

    public boolean isPermissionGranted() {
        checkPermission = ContextCompat.checkSelfPermission(context, permission);
        return checkPermission == PackageManager.PERMISSION_GRANTED;
    }

    public void requestForPermission(final Activity activity) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
            builder.setMessage("App needs permission to access the camera")
                    .setTitle("Requesting Permission");
            builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    ActivityCompat.requestPermissions(activity,
                            new String[]{permission},
                            MY_PERMISSIONS_REQUEST_CAMERA);
                }
            });
            builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    activity.finish();
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();

        } else {
            ActivityCompat.requestPermissions(activity,
                    new String[]{permission},
                    MY_PERMISSIONS_REQUEST_CAMERA);
        }
    }

}
