package com.example.oluwatobiloba.materialdesigntutotial;

import android.animation.Animator;
import android.graphics.Color;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.ActionMode;
import androidx.appcompat.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MenuListAdapter extends RecyclerView.Adapter<MenuListAdapter.MenuViewHolder> {

    List<String> items;

    public MenuListAdapter(List<String> items) {
        this.items = items;
    }

    @Override
    public MenuViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.menu_list_item, parent, false);
        return new MenuViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MenuViewHolder holder, int position) {
        String item = items.get(position);
        holder.itemText.setText(item);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class MenuViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener {
        TextView itemText;

        public MenuViewHolder(View itemView) {
            super(itemView);
            itemText = itemView.findViewById(R.id.menu_list_item);
            itemView.setOnLongClickListener(this);
            itemView.setOnClickListener(this);
        }

        @Override
        public boolean onLongClick(View v) {

            boolean isLongPressed = v.getSolidColor() == Color.MAGENTA;

            final int radius = (int) Math.hypot(v.getWidth() / 2, v.getHeight() / 2);

            if (isLongPressed) {
                v.setBackgroundColor(Color.WHITE);
            } else  {
                Animator anim = ViewAnimationUtils.createCircularReveal(
                        v,
                        (int) v.getWidth() / 2,
                        (int) v.getHeight() / 2,
                        0,
                        radius);
                v.setBackgroundColor(Color.MAGENTA);
                anim.start();
            }

            return true;
        }

        @Override
        public void onClick(View v) {

        }
    }
}
