package com.example.oluwatobiloba.materialdesigntutotial;

import android.animation.Animator;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.DefaultItemAnimator;
import androidx.appcompat.widget.LinearLayoutManager;
import androidx.appcompat.widget.RecyclerView;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private MenuListAdapter mMenuListAdapter;
    List<String> mMenuList = new ArrayList<String>(Arrays.asList("One", "Two", "Three", "Four",
            "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen",
            "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen", "Twenty"));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRecyclerView = findViewById(R.id.menu_recycler_view);
        mMenuListAdapter = new MenuListAdapter(mMenuList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setAdapter(mMenuListAdapter);
        mMenuListAdapter.notifyDataSetChanged();

//        mRecyclerView.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), mRecyclerView, new RecyclerTouchListener.ClickListener() {
//            @Override
//            public void onClick(View view, int position) {
//                Toast.makeText(getApplicationContext(), "Position: " + position, Toast.LENGTH_SHORT);
//            }
//
//            @Override
//            public void onLongClick(View view, int position) {
//                boolean isLongPressed = view.getSolidColor() == Color.MAGENTA;
//
//                final int radius = (int) Math.hypot(view.getWidth() / 2, view.getHeight() / 2);
//
//                if (isLongPressed) {
//                    view.setBackgroundColor(Color.WHITE);
//                } else  {
//                    Animator anim = ViewAnimationUtils.createCircularReveal(
//                            view,
//                            (int) view.getWidth() / 2,
//                            (int) view.getHeight() / 2,
//                            0,
//                            radius);
//                    view.setBackgroundColor(Color.MAGENTA);
//                    anim.start();
//                }
//            }
//        }));
    }
}
